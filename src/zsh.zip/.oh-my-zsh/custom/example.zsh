# Add yourself some shortcuts to projects you often work on
# Example:
#
# brainstormr=/Users/robbyrussell/Projects/development/planetargon/brainstormr
#
DOCKER_MACHINE=/usr/local/bin/docker-machine
VM=default
BLUE='\033[0;34m'
GREEN='\033[0;32m'
NC='\033[0m'

[[ -s /usr/local/etc/autojump.sh ]] && . /usr/local/etc/autojump.sh
alias lg="ls ./ | grep "
alias updatedb="sudo  sh /usr/libexec/locate.updatedb"
export Ring="$HOME/Music/Ring/Bismarck02.mp3";
export Ring2="$HOME/Music/Ring/Bismarck17.mp3";
export PATH=/usr/local/sbin:$PATH

alias h='history | grep ';
export TORSOCKS_CONF_FILE=/etc/torsocks.conf
alias f='proxychains4' 

function  Download {
	
	f wget -c -t 50 $1 && play -q $Ring2 ;
}


alias clearfile="file_classify.py ";
alias google_tr="f google_tr_lib.py ";
alias cn2us="f chinese.py ";
alias fbrew="f brew ";
alias target="146.148.79.13";
alias fpip='f pip';
alias fgit='f git';
export PATH="$PATH:$HOME/Documents/code/Python/Tool/little_message/Google_translate_API";
alias eject='diskutil unmount  ';
#export PYTHONPATH="/usr/local/lib/python3.4/site-packages:"
alias my_ip="ifconfig | grep inet " ; 
alias em="emacs-24.5 ";

function find_minute_ago {
	if [ $# -lt 3 ]
	then 
        	find $1 -newerct "$2 minute ago " -print ;
	else
		echo "cmd : $3";
		find $1 -newerct "$2 minute ago " -type f   -exec  $3 {}  + 
	fi
}
export ANDROID_HOME=/Users/darkh/adt-bundle-mac-x86_64-20140702/sdk
export PATH="/Users/darkh/.rvm/gems/ruby-2.2.0/bin:/Users/darkh/.rvm/gems/ruby-2.2.0@global/bin:/Users/darkh/.rvm/rubies/ruby-2.2.0/bin:/Users/darkh/.rbenv/shims:/usr/bin;/bin:/usr/sbin:/sbin:/usr/local/bin:/usr/local/sbin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:/opt/X11/bin:/Users/darkh/Documents/code/Python/Tool/little_message/Google_translate_API:/Users/darkh/.rvm/bin:/Users/darkh/adt-bundle-mac-x86_64-20140702/sdk/tools" 
export  PATH="/Users/darkh/.rvm/gems/ruby-2.2.0/bin:/Users/darkh/.rvm/gems/ruby-2.2.0@global/bin:/Users/darkh/.rvm/rubies/ruby-2.2.0/bin:/Users/darkh/.rbenv/shims:/usr/bin;/bin:/usr/sbin:/sbin:/usr/local/bin:/Users/darkh/.rvm/gems/ruby-2.2.0/bin:/Users/darkh/.rvm/gems/ruby-2.2.0@global/bin:/Users/darkh/.rvm/rubies/ruby-2.2.0/bin:/Users/darkh/.rbenv/shims:/usr/bin;/bin:/usr/sbin:/sbin:/usr/local/bin:/usr/local/sbin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:/opt/X11/bin:/Users/darkh/Documents/code/Python/Tool/little_message/Google_translate_API:/Users/darkh/.rvm/bin:/Users/darkh/adt-bundle-mac-x86_64-20140702/sdk/tools:/Users/darkh/.rvm/bin:/Users/darkh/adt-bundle-mac-x86_64-20140702/sdk/platform-tools"

###############   FUN ####################
#
#
#
#
###########################################
function viGrep {
	TEXT="$(grep -nr $1 $2 )" ;
	echo  $TEXT;
	echo -n "choose : "
	read NUM;
	echo $TEXT | sed -n "$NUM,$NUM p" | awk -F ":" '{print $1, $2 "+" }' | xargs vi  ;

}



function search-text {
	grep -nr $1 $2;

}


function docker-in {
				eval $($DOCKER_MACHINE env $VM --shell=bash);
cat << EOF
				  
				   
				                          ##         .
				                   ## ## ##        ==
				                ## ## ## ## ##    ===
				            /"""""""""""""""""\___/ ===
				       ~~~ {~~ ~~~~ ~~~ ~~~~ ~~~ ~ /  ===- ~~~
				            \______ o           __/
				              \    \         __/
				               \____\_______/
				  
											 
EOF
				echo  -e "${BLUE} docker  ${NC} $VM ${NC}  is use ip : ${GREEN} $($DOCKER_MACHINE ip $VM) ${GREEN} ${BLUE}";
				eval $($DOCKER_MACHINE env $VM --shell=bash )


}




####################################
###  loading all preload modules ###
####################################

eval "$(thefuck --alias )";


###################################
###  start zsh ####################
###################################

clear;
cat << EOF
				  

                                   ##         .
                            ## ## ##        ==
                         ## ## ## ## ##    ===
                     /"""""""""""""""""\___/ ===
EOF
echo  "${BLUE}                ~~~ {~~ ~~~~ ~~~ ~~~~ ~~~ ~ /  ===- ~~~ ${BLUE}";
echo  "${BLUE}	             \______ o           __/           ${BLUE}	";
echo  "${BLUE}                      \    \         __/               ${BLUE}	";
echo  "${BLUE}	               \____\_______/                  ${BLUE}	";


interface="wlan0";
interface2="eth0";
if [ "$(uname)" = "Darwin" ];
then
				interface="en0";
fi

echo   " ${NC} $(whoami) ${NC} is use ip : ${GREEN} $(ip addr show dev $interface2 | grep inet | grep -v "inet6" | columns 2 ) ${GREEN}";
	
