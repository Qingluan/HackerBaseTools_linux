alias h='history'

function hs
{
    history | grep $*
}

alias hsi='hs -i'
